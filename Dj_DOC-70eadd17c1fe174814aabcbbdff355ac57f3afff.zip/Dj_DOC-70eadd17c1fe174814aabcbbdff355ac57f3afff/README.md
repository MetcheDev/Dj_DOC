# Dj_DOC: Django Documentation Project
This is a test project where I will go through all django documentation step by step and you can follow along.
